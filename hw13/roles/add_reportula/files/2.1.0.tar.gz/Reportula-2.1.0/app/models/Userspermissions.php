<?php

namespace app\models;

use Eloquent;

class Userspermissions extends Eloquent
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'userspermissions';
    public $timestamps = false;

}
