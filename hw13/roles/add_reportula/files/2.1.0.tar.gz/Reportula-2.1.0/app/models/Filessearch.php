<?php

namespace app\models;

use Eloquent;

class Filessearch extends Eloquent
{
    protected $table = 'filessearch';
    public $timestamps = false;
}
