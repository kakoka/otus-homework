<?php

namespace app\models;

use Eloquent;

class Settings extends Eloquent
{
    protected $table = 'settings';

    public $timestamps = false;

}
