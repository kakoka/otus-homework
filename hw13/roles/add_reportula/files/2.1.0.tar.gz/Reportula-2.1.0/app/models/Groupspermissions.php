<?php

namespace app\models;

use Eloquent;

class Groupspermissions extends Eloquent
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'groupspermissions';
    public $timestamps = false;

}
