<?php

namespace app\models;

use Eloquent;
use app\models\BaseModel;

class Cfgfilesetinclude extends BaseModel
{

    protected $guarded = array('id');
    public $key = 'id';
    protected $table = 'cfgfilesetinclude';
    public $timestamps = false;





}
