@extends('admin._layouts.default')
@section('main')
<div class="row-fluid">
  <div class="span12 box-content">
    <div id="console" class="span12">
    </div>
  </div>
</div>
@endsection







